<?php
/**
 * Brasserie WooCommerce hooks
 *
 * @package Brasserie
 */
 
add_action( 'brasserie_header_cart', 'brasserie_mini_cart', 		10 );